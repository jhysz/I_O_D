
DATA   MJD

obs1  53768
obs2  53617
obs3  56123

File Format

Line 1:   Site Coordinate in Body-Fixed X-Y-Z (m)
Line 2+ : YYYY MM DD HH MI SS.SSSS RA(DEG) DEC(DEG) 0  0


Sidreal Time 


SG = 18h.6973746 + 879000h.0513367 t + 0.s093104 t^2 − 6s.2 × 10^−6 t^3
